
package chickens01;

public class Chickens01 {
    public static void main(String[] args) {
        //Put yout code here
        //Caso1
        int eggsPerChicken =5;
        int chickenCount = 3;
        int mondayEggs = eggsPerChicken * chickenCount;
        chickenCount += 1;
        int tuesdayEggs = chickenCount * eggsPerChicken;
        int wednesdayEggs = (chickenCount / 2) * eggsPerChicken;
        int totalEggs = (mondayEggs + tuesdayEggs + wednesdayEggs);
        System.out.printf("el total del primer caso es: %d huevos \n", totalEggs);
        //Caso 2
        eggsPerChicken =4;
        chickenCount = 8;
        mondayEggs = eggsPerChicken * chickenCount;
        chickenCount += 1;
        tuesdayEggs = chickenCount * eggsPerChicken;
        wednesdayEggs = (chickenCount / 2) * eggsPerChicken;
        totalEggs = (mondayEggs + tuesdayEggs + wednesdayEggs);
        System.out.printf("el total del segundo caso es: %d huevos", totalEggs);
        
        
    }   
}
